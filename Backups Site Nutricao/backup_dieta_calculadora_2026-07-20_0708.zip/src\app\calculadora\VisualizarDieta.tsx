"use client"
import { Button } from "@/components/ui/button"
import type { Cardapio } from "@/lib/nutricao"
import { FileText } from "lucide-react"
import type { AlimentoCompleto } from "@/lib/alimentos"

interface Props {
  cardapio: Cardapio
  substitutosColecao?: Record<string, { alimento: AlimentoCompleto; quantidade: number }[]>
}

export function VisualizarDieta({ cardapio, substitutosColecao = {} }: Props) {
  const handleAbrir = () => {
    const janela = window.open("", "_blank")
    if (!janela) return
    const html = gerarHTML(cardapio, substitutosColecao)
    janela.document.write(html)
    janela.document.close()
    janela.focus()
  }

  return (
    <Button variant="outline" size="sm" onClick={handleAbrir}>
      <FileText className="w-4 h-4" /> Ver Cardápio (PDF)
    </Button>
  )
}

function gerarHTML(cardapio: Cardapio, substitutosColecao: Record<string, { alimento: AlimentoCompleto; quantidade: number }[]>): string {
  const now = new Date()
  const dataStr = now.toLocaleDateString("pt-BR")

  return `<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Cardápio Nutricional</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    font-family: 'Times New Roman', Times, serif;
    padding: 40px 50px;
    color: #1a1a1a;
    background: #fff;
  }
  @media print {
    body { padding: 20px; }
    .no-print { display: none !important; }
    @page { margin: 2cm; }
  }
  .header {
    text-align: center;
    border-bottom: 2px solid #243748;
    padding-bottom: 20px;
    margin-bottom: 25px;
  }
  .header h1 { font-size: 22pt; color: #243748; margin-bottom: 5px; font-family: 'Times New Roman', Times, serif; }
  .header p { font-size: 11pt; color: #666; }
  .resumo {
    display: flex;
    gap: 20px;
    justify-content: center;
    margin-bottom: 25px;
    flex-wrap: wrap;
  }
  .resumo-item {
    text-align: center;
    background: #f0fdfa;
    border: 1px solid #20c4b6;
    border-radius: 8px;
    padding: 10px 18px;
    min-width: 100px;
  }
  .resumo-item .valor { font-size: 16pt; font-weight: bold; color: #243748; }
  .resumo-item .rotulo { font-size: 9pt; color: #666; margin-top: 2px; }
  .refeicao {
    margin-bottom: 20px;
    page-break-inside: avoid;
  }
  .refeicao h2 {
    font-size: 14pt;
    color: #243748;
    border-left: 4px solid #20c4b6;
    padding-left: 10px;
    margin-bottom: 8px;
  }
  .refeicao .horario { font-size: 10pt; color: #999; margin-left: 14px; }
  .alimento-principal {
    font-size: 12pt;
    line-height: 1.8;
    padding-left: 14px;
    color: #1a1a1a;
  }
  .medida-caseira {
    font-size: 10pt;
    color: #20c4b6;
    font-style: italic;
  }
  .substitutos-titulo {
    font-size: 9pt;
    padding-left: 28px;
    color: #20c4b6;
    font-weight: bold;
    margin-top: 2px;
  }
  .alimento-substituto {
    font-size: 8pt;
    line-height: 1.6;
    padding-left: 28px;
    color: #888;
    font-style: italic;
  }
</style>
</head>
<body>

<div class="header">
  <h1>Cardápio Nutricional</h1>
  <p>Data: ${dataStr}</p>
</div>

<div class="resumo">
  <div class="resumo-item"><div class="valor">${cardapio.totalKcal}</div><div class="rotulo">Kcal totais</div></div>
  <div class="resumo-item"><div class="valor">${cardapio.totalProteinas}g</div><div class="rotulo">Proteínas</div></div>
  <div class="resumo-item"><div class="valor">${cardapio.totalLipidios}g</div><div class="rotulo">Lipídios</div></div>
  <div class="resumo-item"><div class="valor">${cardapio.totalCarboidratos}g</div><div class="rotulo">Carboidratos</div></div>
  <div class="resumo-item"><div class="valor">${cardapio.totalFibras}g</div><div class="rotulo">Fibras</div></div>
</div>

${cardapio.refeicoes.map((ref, refIdx) => {
  let refHtml = `<div class="refeicao"><h2>${ref.nome} <span class="horario">(${ref.horario})</span></h2>`
  ref.alimentos.forEach((item, alimIdx) => {
    const subsKey = `${refIdx}_${alimIdx}`
    const subs = substitutosColecao[subsKey] || []
    const kcal = item.alimento.kcal ?? 0
    const nomeItem = (item as any).customNome || item.alimento.nome
    const medida = (item as any).medidaCaseira ? ` <span class="medida-caseira">(${(item as any).medidaCaseira})</span>` : ""
    refHtml += `<div class="alimento-principal">${nomeItem} — ${item.quantidade}g${medida} (${Math.round(kcal * item.quantidade / item.alimento.gramas)} kcal)</div>`
    if (subs.length > 0) {
      refHtml += `<div class="substitutos-titulo">Substitutos:</div>`
      subs.forEach(s => {
        const skcal = s.alimento.kcal ?? 0
        refHtml += `<div class="alimento-substituto">${s.alimento.nome} — ${s.quantidade}g (${Math.round(skcal * s.quantidade / s.alimento.gramas)} kcal)</div>`
      })
    }
  })
  refHtml += `<div style="font-size:9pt;padding-left:14px;color:#666;margin-top:4px;">P: ${ref.totalProteinas}g · L: ${ref.totalLipidios}g · C: ${ref.totalCarboidratos}g · Kcal: ${ref.totalKcal}</div>`
  refHtml += `</div>`
  return refHtml
}).join('')}

<div style="margin-top:30px;padding-top:15px;border-top:1px solid #ddd;font-size:9pt;color:#999;text-align:center;">
  Documento gerado em ${dataStr} pelo NutriCare
</div>

<div class="no-print" style="margin-top:20px;text-align:center;">
  <button onclick="window.print()" style="padding:10px 30px;font-size:12pt;background:#243748;color:white;border:none;border-radius:6px;cursor:pointer;">
    Imprimir / Salvar PDF
  </button>
</div>

</body>
</html>`
}
