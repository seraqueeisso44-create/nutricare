"use client"
import { useState, useMemo, useEffect, Suspense } from "react"
import Link from "next/link"
import { useSearchParams } from "next/navigation"
import { AppLayout } from "@/components/layout/AppLayout"
import { obterPaciente, calcularIdade, salvarDieta, obterDieta, novaDietaId, type DietaSalva, type RefeicaoDieta, type AlimentoDieta } from "@/lib/pacientes"
import { Button } from "@/components/ui/button"
import { useToast } from "@/components/ui/toast"
import { ErrorBoundary } from "@/components/ui/ErrorBoundary"
import {
  calcularTMB, calcularGET, calcularMacrosMetodoA, calcularMacrosMetodoB,
  gerarTabelaValidacao, classificarDensidadeCalorica, fatoresAtividade,
  type DadosAntropometricos, type MacrosPrescritas, type Cardapio,
  type Refeicao, type ResultadoGET
} from "@/lib/nutricao"
import { bancoAlimentos } from "@/lib/alimentos"
import type { Alimento } from "@/lib/nutricao"
import type { AlimentoCompleto } from "@/lib/alimentos"
import { GraficoMacros } from "./GraficoMacros"
import { TabelaMicros } from "./TabelaMicros"
import { SubstitutoModal } from "./SubstitutoModal"
import { VisualizarDieta } from "./VisualizarDieta"
import { AdicionarAlimentoModal } from "./AdicionarAlimentoModal"
import {
  User, Calculator, Apple, ClipboardCheck,
  ChevronRight, ChevronLeft, Plus, Check,
  AlertTriangle, BarChart3, ArrowLeftRight, X, Sun, Moon, ChevronDown, UserCheck, Target, Users
} from "lucide-react"

type Step = "dados" | "tmb" | "macros" | "cardapio" | "validacao"

const formulasDisponiveis = [
  "Mifflin-St Jeor (1990)", "Harris-Benedict (1919)", "Harris-Benedict (1984)",
  "FAO/WHO (2004)", "EER/IOM (2005)", "Cunningham (1980)",
  "Katch-McArdle", "Henry & Rees (1991)", "Tinsley (2018)",
]

const steps: { key: Step; label: string; icon: React.ElementType }[] = [
  { key: "dados", label: "Dados", icon: User },
  { key: "tmb", label: "Gasto Energético", icon: Calculator },
  { key: "macros", label: "Macronutrientes", icon: BarChart3 },
  { key: "cardapio", label: "Cardápio", icon: Apple },
  { key: "validacao", label: "Validação", icon: ClipboardCheck },
]

function getFoodById(id: string): AlimentoCompleto | undefined {
  return bancoAlimentos.find(a => a.id === id)
}

function calcIMC(peso: number, alturaCm: number): number {
  if (!peso || !alturaCm) return 0
  const h = alturaCm / 100
  return Math.round(peso / (h * h) * 10) / 10
}

function classifIMC(imc: number): { rotulo: string; cor: string } {
  if (imc < 18.5) return { rotulo: "Abaixo do peso", cor: "text-amber-600" }
  if (imc < 25) return { rotulo: "Peso normal", cor: "text-emerald-600" }
  if (imc < 30) return { rotulo: "Sobrepeso", cor: "text-orange-500" }
  if (imc < 35) return { rotulo: "Obesidade I", cor: "text-red-500" }
  if (imc < 40) return { rotulo: "Obesidade II", cor: "text-red-600" }
  return { rotulo: "Obesidade III", cor: "text-red-700" }
}

export default function CalculadoraPage() {
  return (
    <Suspense fallback={null}>
      <CalculadoraConteudo />
    </Suspense>
  )
}

function CalculadoraConteudo() {
  const { addToast } = useToast()
  const [step, setStep] = useState<Step>("dados")
  const [dados, setDados] = useState<DadosAntropometricos>({
    peso: 0, altura: 0, idade: 0, sexo: "masculino",
  })
  const [formula, setFormula] = useState("Mifflin-St Jeor (1990)")
  const [fatorAtividade, setFatorAtividade] = useState(1.2)
  const [resultadoGET, setResultadoGET] = useState<ResultadoGET | null>(null)
  const [metodoMacros, setMetodoMacros] = useState<"A" | "B">("A")
  const [gKg, setGkg] = useState({ proteinas: 2, lipidios: 1, carboidratos: 3 })
  const [percentMacros, setPercentMacros] = useState({ proteinas: 20, lipidios: 30, carboidratos: 50 })
  const [macrosPrescritas, setMacrosPrescritas] = useState<MacrosPrescritas | null>(null)
  const [dark, setDark] = useState(false)
  const [pacienteNome, setPacienteNome] = useState<string | null>(null)
  const [pacienteObjetivo, setPacienteObjetivo] = useState<string>("")
  const [pacienteId, setPacienteId] = useState<string | null>(null)
  const [dietaEditandoId, setDietaEditandoId] = useState<string | null>(null)
  const searchParams = useSearchParams()

  useEffect(() => {
    if (dark) document.documentElement.classList.add("dark")
    else document.documentElement.classList.remove("dark")
  }, [dark])

  useEffect(() => {
    const id = searchParams.get("paciente")
    if (!id) return
    const p = obterPaciente(id)
    if (!p) return
    setPacienteId(p.id)
    setPacienteNome(p.nome)
    setPacienteObjetivo(p.objetivo || "")
    setDados({
      peso: p.peso || 0,
      altura: p.altura || 0,
      idade: calcularIdade(p.dataNascimento),
      sexo: p.sexo,
    })

    const dietaId = searchParams.get("dieta")
    if (!dietaId) return
    const dieta = obterDieta(p.id, dietaId)
    if (!dieta) return
    setDietaEditandoId(dieta.id)
    const subsCol: Record<string, { alimento: AlimentoCompleto; quantidade: number }[]> = {}
    const refs: Refeicao[] = dieta.refeicoes.map((r, refIdx) => {
      const alimentos = r.alimentos.map((a, alimIdx) => {
        const alimento: AlimentoCompleto = {
          id: a.id, nome: a.nome, origem: (a.origem as Alimento["origem"]) || "TACO",
          medidaCaseira: a.medidaCaseira, gramas: a.gramas,
          proteinas: a.proteinas, lipidios: a.lipidios, carboidratos: a.carboidratos,
          fibras: a.fibras, kcal: a.kcal,
        }
        if (a.substitutos && a.substitutos.length) {
          subsCol[`${refIdx}_${alimIdx}`] = a.substitutos.map(s => ({
            alimento: {
              id: `sub_${s.nome}`, nome: s.nome, origem: "TACO" as Alimento["origem"],
              medidaCaseira: s.medidaCaseira, gramas: s.gramas,
              proteinas: 0, lipidios: 0, carboidratos: 0, kcal: 0,
            },
            quantidade: s.quantidade,
          }))
        }
        return { alimento, quantidade: a.quantidade, medidaCaseira: a.medidaCaseira, customNome: a.customNome }
      })
      const tot = recalcularRefeicao(alimentos)
      return { nome: r.nome, horario: r.horario, alimentos, ...tot }
    })
    setRefeicoes(refs)
    setSubstitutosColecao(subsCol)
    setStep("cardapio")
  }, [searchParams])

  const [refeicoes, setRefeicoes] = useState<Refeicao[]>([
    { nome: "Café da Manhã", horario: "07:00", alimentos: [], totalKcal: 0, totalProteinas: 0, totalLipidios: 0, totalCarboidratos: 0, totalFibras: 0, densidadeCalorica: 0 },
    { nome: "Almoço", horario: "12:00", alimentos: [], totalKcal: 0, totalProteinas: 0, totalLipidios: 0, totalCarboidratos: 0, totalFibras: 0, densidadeCalorica: 0 },
    { nome: "Jantar", horario: "19:00", alimentos: [], totalKcal: 0, totalProteinas: 0, totalLipidios: 0, totalCarboidratos: 0, totalFibras: 0, densidadeCalorica: 0 },
    { nome: "Ceia", horario: "22:00", alimentos: [], totalKcal: 0, totalProteinas: 0, totalLipidios: 0, totalCarboidratos: 0, totalFibras: 0, densidadeCalorica: 0 },
  ])
  const [cardapio, setCardapio] = useState<Cardapio | null>(null)
  const [adicionarModalRef, setAdicionarModalRef] = useState<number | null>(null)
  const [editarAlimento, setEditarAlimento] = useState<{ refIdx: number; alimIdx: number } | null>(null)
  const [editQtd, setEditQtd] = useState(0)
  const [editNome, setEditNome] = useState("")
  const [dragIdx, setDragIdx] = useState<number | null>(null)
  const [substitutoAberto, setSubstitutoAberto] = useState(false)
  const [substitutoInfo, setSubstitutoInfo] = useState<{ refIdx: number; alimIdx: number } | null>(null)
  const [substitutosColecao, setSubstitutosColecao] = useState<Record<string, { alimento: AlimentoCompleto; quantidade: number }[]>>({})
  const [substitutosExpandidos, setSubstitutosExpandidos] = useState<Record<string, boolean>>({})

  useEffect(() => {
    if (!resultadoGET || !dados.peso || !dados.altura || !dados.idade) return
    const r = calcularTMB(formula, dados.peso, dados.altura, dados.idade, dados.sexo)
    setResultadoGET(calcularGET(r, fatorAtividade, dados))
  }, [formula, fatorAtividade])

  const sn = (v: number | undefined | null) => v ?? 0
  const imc = calcIMC(dados.peso, dados.altura)
  const classIMC = classifIMC(imc)

  const handleCalcularTMB = () => {
    if (!dados.peso || !dados.altura || !dados.idade) {
      addToast("error", "Preencha peso, altura e idade"); return
    }
    const r = calcularTMB(formula, dados.peso, dados.altura, dados.idade, dados.sexo)
    setResultadoGET(calcularGET(r, fatorAtividade, dados))
    setStep("tmb")
  }

  const handleCalcularGET = () => setStep("macros")

  const handleCalcularMacros = () => {
    if (!resultadoGET) return
    let resultado: MacrosPrescritas
    if (metodoMacros === "A") {
      resultado = calcularMacrosMetodoA(dados.peso, gKg.proteinas, gKg.lipidios, gKg.carboidratos)
    } else {
      resultado = calcularMacrosMetodoB(resultadoGET.get, percentMacros.proteinas, percentMacros.lipidios, percentMacros.carboidratos)
    }
    setMacrosPrescritas(resultado)
    setStep("cardapio")
  }

  

  const recalcularRefeicao = (alimentos: { alimento: Alimento; quantidade: number; customNome?: string }[]) => {
    const totalKcal = Math.round(alimentos.reduce((s, i) => s + sn(i.alimento.kcal) * i.quantidade / i.alimento.gramas, 0))
    const totalProteinas = Math.round(alimentos.reduce((s, i) => s + sn(i.alimento.proteinas) * i.quantidade / i.alimento.gramas, 0) * 10) / 10
    const totalLipidios = Math.round(alimentos.reduce((s, i) => s + sn(i.alimento.lipidios) * i.quantidade / i.alimento.gramas, 0) * 10) / 10
    const totalCarboidratos = Math.round(alimentos.reduce((s, i) => s + sn(i.alimento.carboidratos) * i.quantidade / i.alimento.gramas, 0) * 10) / 10
    const totalFibras = Math.round(alimentos.reduce((s, i) => s + sn(i.alimento.fibras) * i.quantidade / i.alimento.gramas, 0) * 10) / 10
    const totalGramas = totalProteinas + totalLipidios + totalCarboidratos
    return { totalKcal, totalProteinas, totalLipidios, totalCarboidratos, totalFibras, densidadeCalorica: totalGramas > 0 ? Math.round(totalKcal / totalGramas * 100) / 100 : 0 }
  }

  const handleAdicionarAlimento = (alimento: AlimentoCompleto, refIdx: number, gramas: number, medidaCaseira?: string) => {
    setRefeicoes(prev => {
      const updated = [...prev]
      const ref = { ...updated[refIdx] }
      const alimentos = [...ref.alimentos, { alimento, quantidade: gramas, medidaCaseira }]
      const tot = recalcularRefeicao(alimentos)
      updated[refIdx] = { ...ref, alimentos, ...tot }
      return updated
    })
    addToast("success", `${alimento.nome} adicionado`)
  }

  const handleRemoverAlimento = (refIdx: number, alimIdx: number) => {
    setRefeicoes(prev => {
      const updated = [...prev]
      const ref = { ...updated[refIdx] }
      const alimentos = ref.alimentos.filter((_, i) => i !== alimIdx)
      const tot = recalcularRefeicao(alimentos)
      updated[refIdx] = { ...ref, alimentos, ...tot }
      return updated
    })
  }

  const adicionarRefeicao = () => {
    const num = refeicoes.length + 1
    setRefeicoes(prev => [...prev, { nome: `Refeição ${num}`, horario: "12:00", alimentos: [], totalKcal: 0, totalProteinas: 0, totalLipidios: 0, totalCarboidratos: 0, totalFibras: 0, densidadeCalorica: 0 }])
  }

  const removerRefeicao = (idx: number) => {
    if (refeicoes.length <= 1) { addToast("error", "Mínimo 1 refeição"); return }
    setRefeicoes(prev => prev.filter((_, i) => i !== idx))
  }

  const duplicarRefeicao = (idx: number) => {
    const ref = refeicoes[idx]
    const dup = { ...ref, nome: `${ref.nome} (cópia)` }
    setRefeicoes(prev => { const upd = [...prev]; upd.splice(idx + 1, 0, dup); return upd })
  }

  const handleMoverRefeicao = (from: number, to: number) => {
    if (to < 0 || to >= refeicoes.length) return
    setRefeicoes(prev => { const upd = [...prev]; const [m] = upd.splice(from, 1); upd.splice(to, 0, m); return upd })
  }

  const handleEditarQuantidade = (refIdx: number, alimIdx: number, gramas: number, nome?: string) => {
    setRefeicoes(prev => {
      const updated = [...prev]
      const ref = { ...updated[refIdx] }
      const alimentos = [...ref.alimentos]
      alimentos[alimIdx] = { ...alimentos[alimIdx], quantidade: gramas, customNome: nome || undefined } as any
      const tot = recalcularRefeicao(alimentos)
      updated[refIdx] = { ...ref, alimentos, ...tot }
      return updated
    })
    setEditarAlimento(null)
    addToast("success", "Quantidade atualizada")
  }

  const handleTrocarSubstituto = (refIdx: number, alimIdx: number, subIdx: number) => {
    const key = `${refIdx}_${alimIdx}`
    const mainItem = refeicoes[refIdx]?.alimentos[alimIdx]
    const subsArr = substitutosColecao[key] || []
    const subItem = subsArr[subIdx]
    if (!mainItem || !subItem) return
    setRefeicoes(prev => {
      const updated = [...prev]
      const ref = { ...updated[refIdx] }
      const alimentos = [...ref.alimentos]
      alimentos[alimIdx] = { alimento: subItem.alimento, quantidade: subItem.quantidade }
      const tot = recalcularRefeicao(alimentos)
      updated[refIdx] = { ...ref, alimentos, ...tot }
      return updated
    })
    setSubstitutosColecao(prev => {
      const arr = [...(prev[key] || [])]
      arr[subIdx] = { alimento: mainItem.alimento, quantidade: mainItem.quantidade }
      return { ...prev, [key]: arr }
    })
    addToast("success", `"${subItem.alimento.nome}" virou principal, "${mainItem.alimento.nome}" virou substituto`)
  }

  const handleGerarCardapio = () => {
    const card: Cardapio = {
      refeicoes,
      totalProteinas: Math.round(refeicoes.reduce((s, r) => s + r.totalProteinas, 0) * 10) / 10,
      totalLipidios: Math.round(refeicoes.reduce((s, r) => s + r.totalLipidios, 0) * 10) / 10,
      totalCarboidratos: Math.round(refeicoes.reduce((s, r) => s + r.totalCarboidratos, 0) * 10) / 10,
      totalFibras: Math.round(refeicoes.reduce((s, r) => s + r.totalFibras, 0) * 10) / 10,
      totalKcal: Math.round(refeicoes.reduce((s, r) => s + r.totalKcal, 0)),
    }
    setCardapio(card); setStep("validacao")
  }

  const validacao = useMemo(() => {
    if (!macrosPrescritas || !cardapio) return []
    return gerarTabelaValidacao(macrosPrescritas, cardapio)
  }, [macrosPrescritas, cardapio])

  const handleSalvarPrescricao = () => {
    if (!cardapio) return
    if (!pacienteId) {
      addToast("info", "Nenhum paciente vinculado. Abra a calculadora a partir de um paciente para salvar a dieta no perfil.")
      return
    }
    const refeicoesDieta: RefeicaoDieta[] = cardapio.refeicoes.map((r, refIdx) => ({
      nome: r.nome,
      horario: r.horario,
      totalKcal: r.totalKcal,
      totalProteinas: r.totalProteinas,
      totalLipidios: r.totalLipidios,
      totalCarboidratos: r.totalCarboidratos,
      totalFibras: r.totalFibras,
      alimentos: r.alimentos.map((item, alimIdx): AlimentoDieta => {
        const subs = substitutosColecao[`${refIdx}_${alimIdx}`] || []
        return {
          id: item.alimento.id,
          nome: item.customNome || item.alimento.nome,
          origem: item.alimento.origem,
          medidaCaseira: item.medidaCaseira || item.alimento.medidaCaseira || "",
          gramas: item.alimento.gramas,
          quantidade: item.quantidade,
          proteinas: item.alimento.proteinas,
          lipidios: item.alimento.lipidios,
          carboidratos: item.alimento.carboidratos,
          fibras: item.alimento.fibras,
          kcal: item.alimento.kcal,
          customNome: item.customNome,
          substitutos: subs.map(s => ({
            nome: s.alimento.nome,
            gramas: s.alimento.gramas,
            medidaCaseira: s.alimento.medidaCaseira || "",
            quantidade: s.quantidade,
          })),
        }
      }),
    }))

    const agora = new Date()
    const dieta: DietaSalva = {
      id: dietaEditandoId || novaDietaId(),
      data: agora.toISOString().slice(0, 10),
      titulo: dietaEditandoId ? "Dieta atualizada" : `Dieta ${agora.toLocaleDateString("pt-BR")}`,
      refeicoes: refeicoesDieta,
      totalKcal: cardapio.totalKcal,
      totalProteinas: cardapio.totalProteinas,
      totalLipidios: cardapio.totalLipidios,
      totalCarboidratos: cardapio.totalCarboidratos,
      totalFibras: cardapio.totalFibras,
      metaKcal: macrosPrescritas?.kcalTotal,
      metaProteinas: macrosPrescritas?.proteinasG,
      metaLipidios: macrosPrescritas?.lipidiosG,
      metaCarboidratos: macrosPrescritas?.carboidratosG,
    }

    const atualizado = salvarDieta(pacienteId, dieta)
    if (atualizado) {
      setDietaEditandoId(dieta.id)
      addToast("success", dietaEditandoId
        ? `Dieta atualizada no perfil de ${pacienteNome}`
        : `Dieta salva no perfil de ${pacienteNome}`)
    } else {
      addToast("error", "Não foi possível salvar a dieta")
    }
  }

  const totalProteinas = refeicoes.reduce((s, r) => s + r.totalProteinas, 0)
  const totalLipidios = refeicoes.reduce((s, r) => s + r.totalLipidios, 0)
  const totalCarboidratos = refeicoes.reduce((s, r) => s + r.totalCarboidratos, 0)

  const macrosEstimados = useMemo(() => {
    if (!resultadoGET) return null
    const get = resultadoGET.get
    return {
      proteinasG: Math.round(gKg.proteinas * dados.peso),
      lipidiosG: Math.round(gKg.lipidios * dados.peso),
      carboidratosG: Math.round(gKg.carboidratos * dados.peso),
      proteinasKcal: Math.round(gKg.proteinas * dados.peso * 4),
      lipidiosKcal: Math.round(gKg.lipidios * dados.peso * 9),
      carboidratosKcal: Math.round(gKg.carboidratos * dados.peso * 4),
      kcalTotal: Math.round((gKg.proteinas * dados.peso * 4) + (gKg.lipidios * dados.peso * 9) + (gKg.carboidratos * dados.peso * 4)),
    }
  }, [metodoMacros, gKg, percentMacros, dados.peso, resultadoGET])

  return (
    <AppLayout>
      <ErrorBoundary>
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-petroleo to-turquesa flex items-center justify-center">
              <Apple className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900 dark:text-white">Calculadora de Cardápios</h1>
              {pacienteNome
                ? <p className="text-xs text-turquesa font-medium">Paciente: {pacienteNome}</p>
                : <p className="text-xs text-gray-500">TACO · TMB · Macros · Validação</p>}
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Link href={pacienteId ? `/pacientes/${pacienteId}` : "/pacientes"}
              className="flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-petroleo text-white hover:bg-petroleo/90 transition-all text-sm font-medium"
              title="Ir para Pacientes">
              <Users className="w-4 h-4" />
              <span className="hidden sm:inline">{pacienteId ? "Voltar ao Paciente" : "Pacientes"}</span>
            </Link>
            <button onClick={() => setDark(!dark)}
              className="p-2.5 rounded-xl bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 transition-all text-gray-600 dark:text-gray-300"
              title={dark ? "Modo claro" : "Modo escuro"}>
              {dark ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* STEP INDICATOR */}
        <div className="flex items-center gap-1 bg-white dark:bg-gray-900 rounded-xl border border-gray-100 dark:border-gray-800 p-1.5 shadow-sm">
          {steps.map((s, i) => {
            const Icon = s.icon
            const active = step === s.key
            const done = steps.findIndex(st => st.key === step) > i
            return (
              <button key={s.key} onClick={() => setStep(s.key)}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-all flex-1 justify-center ${active ? 'bg-petroleo text-white shadow-sm' : done ? 'text-turquesa' : 'text-gray-400 dark:text-gray-500'}`}>
                <Icon className="w-4 h-4" />
                <span className="hidden sm:inline">{s.label}</span>
              </button>
            )
          })}
        </div>

        {/* STEP 1 - DADOS */}
        {step === "dados" && (
          <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-100 dark:border-gray-800 p-6 shadow-sm space-y-4">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white flex items-center gap-2"><User className="w-5 h-5 text-turquesa" /> Dados do Paciente</h2>
            {pacienteNome && (
              <div className="flex items-start gap-2 p-3 bg-turquesa/10 border border-turquesa/30 rounded-lg text-sm">
                <UserCheck className="w-5 h-5 text-turquesa flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-medium text-petroleo dark:text-turquesa">Dados importados de: {pacienteNome}</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    Peso, altura, idade e sexo foram preenchidos automaticamente.
                    {pacienteObjetivo && <> Objetivo: <span className="inline-flex items-center gap-1"><Target className="w-3 h-3" /> {pacienteObjetivo}</span></>}
                  </p>
                </div>
              </div>
            )}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div><label className="text-xs text-gray-500 mb-1 block">Peso (kg)</label>
                <input type="number" value={dados.peso || ""} onChange={e => setDados(p => ({ ...p, peso: parseFloat(e.target.value) || 0 }))} className="w-full h-10 px-3 rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm focus:ring-2 focus:ring-turquesa dark:text-white" /></div>
              <div><label className="text-xs text-gray-500 mb-1 block">Altura (cm)</label>
                <input type="number" value={dados.altura || ""} onChange={e => setDados(p => ({ ...p, altura: parseFloat(e.target.value) || 0 }))} className="w-full h-10 px-3 rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm focus:ring-2 focus:ring-turquesa dark:text-white" /></div>
              <div><label className="text-xs text-gray-500 mb-1 block">Idade</label>
                <input type="number" value={dados.idade || ""} onChange={e => setDados(p => ({ ...p, idade: parseFloat(e.target.value) || 0 }))} className="w-full h-10 px-3 rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm focus:ring-2 focus:ring-turquesa dark:text-white" /></div>
              <div><label className="text-xs text-gray-500 mb-1 block">Sexo</label>
                <select value={dados.sexo} onChange={e => setDados(p => ({ ...p, sexo: e.target.value as "masculino" | "feminino" }))} className="w-full h-10 px-3 rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm focus:ring-2 focus:ring-turquesa dark:text-white">
                  <option value="masculino">Masculino</option><option value="feminino">Feminino</option>
                </select></div>
            </div>
            {dados.peso > 0 && dados.altura > 0 && (
              <div className="flex items-center gap-4 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                <div className="text-center">
                  <p className="text-xs text-gray-500">IMC</p>
                  <p className="text-2xl font-bold text-petroleo dark:text-turquesa">{imc}</p>
                </div>
                <div className="text-sm">
                  <p className={`font-semibold ${classIMC.cor}`}>{classIMC.rotulo}</p>
                  <p className="text-gray-400 text-xs">{dados.peso}kg / {dados.altura}cm</p>
                </div>
              </div>
            )}
            <div className="flex justify-end">
              <Button onClick={handleCalcularTMB}>Calcular TMB <ChevronRight className="w-4 h-4" /></Button>
            </div>
          </div>
        )}

        {/* STEP 2 - TMB / GET */}
        {step === "tmb" && resultadoGET && (
          <div className="space-y-4">
            <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-100 dark:border-gray-800 p-6 shadow-sm space-y-4">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white flex items-center gap-2"><Calculator className="w-5 h-5 text-turquesa" /> Gasto Energético</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs text-gray-500 mb-1 block">Fórmula</label>
                  <select value={formula} onChange={e => setFormula(e.target.value)} className="w-full h-10 px-3 rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm dark:text-white">
                    {formulasDisponiveis.map(f => <option key={f} value={f}>{f}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-xs text-gray-500 mb-1 block">Fator Atividade</label>
                  <select value={fatorAtividade} onChange={e => setFatorAtividade(parseFloat(e.target.value))} className="w-full h-10 px-3 rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm dark:text-white">
                    {fatoresAtividade.map(f => <option key={f.valor} value={f.valor}>{f.rotulo} ({f.valor})</option>)}
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[
                  { label: "TMB", value: `${resultadoGET.tmb.tmb} kcal`, color: "text-petroleo dark:text-turquesa" },
                  { label: "Fator", value: resultadoGET.fatorAtividade, color: "text-gray-600 dark:text-gray-300" },
                  { label: "GET Total", value: `${resultadoGET.get} kcal`, color: "text-turquesa font-bold" },
                  { label: "GET/kg", value: `${resultadoGET.getKg} kcal/kg`, color: "text-gray-500 dark:text-gray-400" },
                ].map(item => (
                  <div key={item.label} className="bg-gray-50 dark:bg-gray-800 rounded-lg p-3 text-center"><p className="text-xs text-gray-500 mb-1">{item.label}</p><p className={`text-lg ${item.color}`}>{item.value}</p></div>
                ))}
              </div>
              <p className="text-xs text-gray-400">Fórmula aplicada: <strong>{resultadoGET.tmb.formula}</strong> · TMB: {resultadoGET.tmb.tmb} kcal × FA {resultadoGET.fatorAtividade}</p>
              {resultadoGET.ajustes.length > 0 && (
                <div className="text-xs text-gray-500"><strong>Ajustes:</strong> {resultadoGET.ajustes.map(a => `${a.nome} (${a.valor}%)`).join(", ")}</div>
              )}
              <div className="flex justify-between">
                <Button variant="outline" onClick={() => setStep("dados")}><ChevronLeft className="w-4 h-4" /> Voltar</Button>
                <Button onClick={handleCalcularGET}>Macronutrientes <ChevronRight className="w-4 h-4" /></Button>
              </div>
            </div>
          </div>
        )}

        {/* STEP 3 - MACROS */}
        {step === "macros" && (
          <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-100 dark:border-gray-800 p-6 shadow-sm space-y-4">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white flex items-center gap-2"><BarChart3 className="w-5 h-5 text-turquesa" /> Macros</h2>
            <div className="flex gap-2 mb-2">
              {(["A", "B"] as const).map(m => (
                <button key={m} onClick={() => setMetodoMacros(m)}
                  className={`px-4 py-1.5 rounded-lg text-sm font-medium ${metodoMacros === m ? 'bg-petroleo text-white' : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300'}`}>
                  Método {m === "A" ? "g/kg" : "% GET"}
                </button>
              ))}
            </div>
            <div className="grid grid-cols-3 gap-4">
              {(metodoMacros === "A"
                ? [
                  { label: "Proteínas (g/kg)", key: "proteinas" as const, val: gKg.proteinas },
                  { label: "Lipídios (g/kg)", key: "lipidios" as const, val: gKg.lipidios },
                  { label: "Carboidratos (g/kg)", key: "carboidratos" as const, val: gKg.carboidratos },
                ]
                : [
                  { label: "Proteínas (%)", key: "proteinas" as const, val: percentMacros.proteinas },
                  { label: "Lipídios (%)", key: "lipidios" as const, val: percentMacros.lipidios },
                  { label: "Carboidratos (%)", key: "carboidratos" as const, val: percentMacros.carboidratos },
                ]
              ).map(item => (
                <div key={item.key}><label className="text-xs text-gray-500 mb-1 block">{item.label}</label>
                  <input type="number" value={item.val} onChange={e => {
                    const v = parseFloat(e.target.value) || 0
                    metodoMacros === "A"
                      ? setGkg(p => ({ ...p, [item.key]: v }))
                      : setPercentMacros(p => ({ ...p, [item.key]: v }))
                  }} className="w-full h-10 px-3 rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm focus:ring-2 focus:ring-turquesa dark:text-white" /></div>
              ))}
            </div>

            {/* Prescrito/Recomendado */}
            {(macrosPrescritas || macrosEstimados) && (
              <div className="grid grid-cols-4 gap-3 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                <div className="text-center"><p className="text-xs text-gray-500 mb-1">Proteínas</p><p className="text-lg font-bold text-petroleo dark:text-turquesa">{(macrosPrescritas || macrosEstimados)?.proteinasG ?? 0}g</p><p className="text-xs text-gray-400">{(macrosPrescritas || macrosEstimados)?.proteinasKcal ?? 0} kcal</p></div>
                <div className="text-center"><p className="text-xs text-gray-500 mb-1">Lipídios</p><p className="text-lg font-bold text-turquesa">{(macrosPrescritas || macrosEstimados)?.lipidiosG ?? 0}g</p><p className="text-xs text-gray-400">{(macrosPrescritas || macrosEstimados)?.lipidiosKcal ?? 0} kcal</p></div>
                <div className="text-center"><p className="text-xs text-gray-500 mb-1">Carboidratos</p><p className="text-lg font-bold text-gray-900 dark:text-white">{(macrosPrescritas || macrosEstimados)?.carboidratosG ?? 0}g</p><p className="text-xs text-gray-400">{(macrosPrescritas || macrosEstimados)?.carboidratosKcal ?? 0} kcal</p></div>
                <div className="text-center"><p className="text-xs text-gray-500 mb-1">Total</p><p className="text-lg font-bold text-gray-900 dark:text-white">{(macrosPrescritas || macrosEstimados)?.kcalTotal ?? 0} kcal</p></div>
              </div>
            )}
            {macrosPrescritas && (
              <p className="text-xs text-gray-400">{macrosPrescritas.metodos}</p>
            )}

            <div className="flex justify-between">
              <Button variant="outline" onClick={() => setStep("tmb")}><ChevronLeft className="w-4 h-4" /> Voltar</Button>
              <Button onClick={handleCalcularMacros}>{macrosPrescritas ? "Recalcular" : "Calcular Macros"} {!macrosPrescritas && <ChevronRight className="w-4 h-4" />}</Button>
            </div>
          </div>
        )}

        {/* STEP 4 - CARDÁPIO */}
        {step === "cardapio" && (
          <div className="space-y-4">
            <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-100 dark:border-gray-800 p-6 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-gray-900 dark:text-white flex items-center gap-2"><Apple className="w-5 h-5 text-turquesa" /> Cardápio</h2>
                <Button variant="outline" size="sm" onClick={adicionarRefeicao}>
                  <Plus className="w-4 h-4" /> Refeição
                </Button>
              </div>

              {/* REFEIÇÕES */}
              <div className="space-y-3">
                {refeicoes.map((ref, refIdx) => (
                  <div key={refIdx}
                    draggable
                    onDragStart={() => setDragIdx(refIdx)}
                    onDragOver={e => { e.preventDefault(); if (dragIdx !== null && dragIdx !== refIdx) handleMoverRefeicao(dragIdx, refIdx); setDragIdx(refIdx) }}
                    onDragEnd={() => setDragIdx(null)}
                    className={`border border-gray-100 dark:border-gray-800 rounded-xl p-4 transition-all ${dragIdx === refIdx ? 'opacity-50 ring-2 ring-turquesa' : ''}`}>
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2 flex-1">
                        <span className="text-gray-300 dark:text-gray-600 cursor-grab active:cursor-grabbing text-lg" title="Arrastar para reordenar">⋮⋮</span>
                        <input type="text" value={ref.nome} onChange={e => {
                          setRefeicoes(prev => {
                            const upd = [...prev]; upd[refIdx] = { ...upd[refIdx], nome: e.target.value }; return upd
                          })
                        }}
                          className="font-semibold text-sm bg-transparent border-none focus:outline-none text-gray-900 dark:text-white w-32" />
                        <input type="time" value={ref.horario} onChange={e => {
                          setRefeicoes(prev => {
                            const upd = [...prev]; upd[refIdx] = { ...upd[refIdx], horario: e.target.value }; return upd
                          })
                        }}
                          className="text-xs text-gray-400 bg-transparent border border-gray-200 dark:border-gray-700 rounded px-1.5 py-0.5" />
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-gray-500">{ref.totalKcal}kcal | P:{ref.totalProteinas}g L:{ref.totalLipidios}g C:{ref.totalCarboidratos}g</span>
                        <button onClick={() => duplicarRefeicao(refIdx)}
                          className="p-1 rounded hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-400 hover:text-turquesa transition-colors" title="Duplicar refeição">
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>
                        </button>
                        <button onClick={() => removerRefeicao(refIdx)}
                          className="p-1 rounded hover:bg-red-50 dark:hover:bg-red-900/20 text-gray-400 hover:text-red-500 transition-colors" title="Remover refeição">
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    {ref.alimentos.length === 0 ? (
                      <p className="text-xs text-gray-400 py-2 text-center">Nenhum alimento adicionado</p>
                    ) : (
                      <div className="space-y-1 mb-3">
                        {ref.alimentos.map((item, alimIdx) => {
                          const key = `${refIdx}_${alimIdx}`
                          const subs = substitutosColecao[key] || []
                          const temSubs = subs.length > 0
                          const expandido = !!substitutosExpandidos[key]
                          return (
                            <div key={alimIdx}>
                              <div
                                onClick={temSubs ? () => setSubstitutosExpandidos(prev => ({ ...prev, [key]: !prev[key] })) : undefined}
                                className={`flex items-center justify-between rounded-lg px-3 py-2 text-sm transition-colors ${temSubs ? 'bg-turquesa/10 dark:bg-turquesa/20 border border-turquesa/40 cursor-pointer hover:bg-turquesa/20' : 'bg-gray-50 dark:bg-gray-800'}`}>
                                <div className="flex items-center gap-2 flex-1 min-w-0">
                                  {temSubs && (
                                    <ChevronDown className={`w-3.5 h-3.5 shrink-0 text-turquesa transition-transform ${expandido ? '' : '-rotate-90'}`} />
                                  )}
                                  <span className={`font-medium truncate ${temSubs ? 'text-petroleo dark:text-turquesa' : 'text-gray-800 dark:text-gray-200'}`}>{(item as any).customNome || item.alimento.nome}</span>
                                  <span className="text-gray-400 shrink-0">{item.quantidade}g</span>
                                  <span className="text-gray-400 shrink-0">{Math.round(sn(item.alimento.kcal) * item.quantidade / item.alimento.gramas)}kcal</span>
                                  <span className="text-gray-400 shrink-0">
                                    P:{Math.round(sn(item.alimento.proteinas) * item.quantidade / item.alimento.gramas * 10) / 10}
                                    L:{Math.round(sn(item.alimento.lipidios) * item.quantidade / item.alimento.gramas * 10) / 10}
                                    C:{Math.round(sn(item.alimento.carboidratos) * item.quantidade / item.alimento.gramas * 10) / 10}
                                  </span>
                                </div>
                                <div className="flex items-center gap-1 shrink-0">
                                  <button onClick={(e) => { e.stopPropagation(); setEditarAlimento({ refIdx, alimIdx }); setEditQtd(item.quantidade); setEditNome((item as any).customNome || item.alimento.nome) }}
                                    className="p-1 rounded hover:bg-gray-200 dark:hover:bg-gray-700 text-gray-400 hover:text-amber-500 transition-colors" title="Editar quantidade/medida">
                                    <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" /></svg>
                                  </button>
                                  <button onClick={(e) => { e.stopPropagation(); setSubstitutoInfo({ refIdx, alimIdx }); setSubstitutoAberto(true) }}
                                    className="p-1 rounded hover:bg-gray-200 dark:hover:bg-gray-700 text-gray-400 hover:text-turquesa transition-colors" title="Adicionar substituto">
                                    <Plus className="w-3.5 h-3.5" />
                                  </button>
                                  <button onClick={(e) => { e.stopPropagation(); handleRemoverAlimento(refIdx, alimIdx) }}
                                    className="p-1 rounded hover:bg-gray-200 dark:hover:bg-gray-700 text-gray-400 hover:text-red-500 transition-colors">
                                    <X className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              </div>
                              {temSubs && expandido && (
                                <div className="ml-4 mt-1 space-y-1">
                                  {subs.map((sub, subIdx) => (
                                    <div key={subIdx} className="flex items-center justify-between bg-amber-50 dark:bg-amber-900/20 rounded-lg px-3 py-1.5 text-xs border border-amber-100 dark:border-amber-800">
                                      <div className="flex items-center gap-2 flex-1 min-w-0">
                                        <ArrowLeftRight className="w-3 h-3 text-amber-500 shrink-0" />
                                        <span className="text-amber-800 dark:text-amber-300 truncate">{sub.alimento.nome}</span>
                                        <span className="text-amber-600 dark:text-amber-400">{sub.quantidade}g</span>
                                        <span className="text-amber-600 dark:text-amber-400">
                                          P:{Math.round(sn(sub.alimento.proteinas) * sub.quantidade / sub.alimento.gramas * 10) / 10}
                                          L:{Math.round(sn(sub.alimento.lipidios) * sub.quantidade / sub.alimento.gramas * 10) / 10}
                                          C:{Math.round(sn(sub.alimento.carboidratos) * sub.quantidade / sub.alimento.gramas * 10) / 10}
                                        </span>
                                      </div>
                                      <button onClick={() => handleTrocarSubstituto(refIdx, alimIdx, subIdx)}
                                        className="text-amber-600 dark:text-amber-400 hover:text-amber-800 font-medium shrink-0 ml-2" title="Trocar">
                                        Trocar
                                      </button>
                                    </div>
                                  ))}
                                </div>
                              )}
                            </div>
                          )
                        })}
                      </div>
                    )}

                    <button onClick={() => setAdicionarModalRef(refIdx)}
                      className="w-full text-center py-1.5 rounded-lg text-xs font-medium text-turquesa hover:bg-turquesa/5 border border-dashed border-gray-200 dark:border-gray-700 transition-all">
                      + Adicionar Alimento
                    </button>
                  </div>
                ))}
              </div>

              {/* FOOD BROWSER MODAL */}
              <AdicionarAlimentoModal
                aberto={adicionarModalRef !== null}
                onClose={() => setAdicionarModalRef(null)}
                onAdicionar={(alimento, gramas, medidaCaseira) => {
                  if (adicionarModalRef === null) return
                  handleAdicionarAlimento(alimento, adicionarModalRef, gramas, medidaCaseira)
                  setAdicionarModalRef(null)
                }}
                nomeRefeicao={adicionarModalRef !== null ? refeicoes[adicionarModalRef]?.nome : ""}
              />

              {/* EDITAR QUANTIDADE MODAL */}
              {editarAlimento && (() => {
                const item = refeicoes[editarAlimento.refIdx]?.alimentos[editarAlimento.alimIdx]
                if (!item) return null
                return (
                  <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40" onClick={() => setEditarAlimento(null)}>
                    <div className="bg-white dark:bg-gray-900 rounded-xl shadow-2xl max-w-sm w-full mx-4 p-6" onClick={e => e.stopPropagation()}>
                      <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-1">Editar item</h3>
                      <label className="text-xs text-gray-500 mb-1 block">Nome (opcional)</label>
                      <input type="text" value={editNome}
                        onChange={e => setEditNome(e.target.value)}
                        className="w-full h-10 px-3 rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm focus:ring-2 focus:ring-turquesa dark:text-white mb-3" />
                      <label className="text-xs text-gray-500 mb-1 block">Quantidade (g)</label>
                      <input type="number" value={editQtd} min={1} step={1}
                        onChange={e => setEditQtd(Math.max(1, parseFloat(e.target.value) || item.quantidade))}
                        className="w-full h-10 px-3 rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm focus:ring-2 focus:ring-turquesa dark:text-white mb-1" />
                      <p className="text-xs text-gray-400 mb-4">
                        {Math.round(sn(item.alimento.kcal) * editQtd / item.alimento.gramas)} kcal
                        {" · P:"}{Math.round(sn(item.alimento.proteinas) * editQtd / item.alimento.gramas * 10) / 10}g
                        {" L:"}{Math.round(sn(item.alimento.lipidios) * editQtd / item.alimento.gramas * 10) / 10}g
                        {" C:"}{Math.round(sn(item.alimento.carboidratos) * editQtd / item.alimento.gramas * 10) / 10}g
                      </p>
                      <div className="flex gap-2">
                        <Button variant="outline" className="flex-1" onClick={() => setEditarAlimento(null)}>Cancelar</Button>
                        <Button className="flex-1" onClick={() => handleEditarQuantidade(editarAlimento.refIdx, editarAlimento.alimIdx, editQtd, editNome)}>
                          Salvar
                        </Button>
                      </div>
                    </div>
                  </div>
                )
              })()}

              <div className="flex items-center justify-between mt-4 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                <div className="grid grid-cols-5 gap-4 text-center text-xs flex-1">
                  <div><span className="text-gray-500">Kcal</span><p className="font-bold text-gray-900 dark:text-white">{refeicoes.reduce((s, r) => s + r.totalKcal, 0)}</p></div>
                  <div><span className="text-gray-500">Proteínas</span><p className="font-bold text-petroleo dark:text-turquesa">{totalProteinas.toFixed(1)}g</p></div>
                  <div><span className="text-gray-500">Lipídios</span><p className="font-bold text-turquesa">{totalLipidios.toFixed(1)}g</p></div>
                  <div><span className="text-gray-500">Carboidratos</span><p className="font-bold text-gray-900 dark:text-white">{totalCarboidratos.toFixed(1)}g</p></div>
                  <div><span className="text-gray-500">Dens. calórica</span><p className="font-bold text-gray-900 dark:text-white">{refeicoes.length > 0 ? (refeicoes.reduce((s, r) => s + r.totalKcal, 0) / Math.max(1, refeicoes.reduce((s, r) => s + r.totalProteinas + r.totalLipidios + r.totalCarboidratos, 0))).toFixed(2) : "0"} kcal/g</p></div>
                </div>
              </div>

              {macrosPrescritas && (
                <div className="mt-3 p-3 bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-lg">
                  <p className="text-xs font-semibold text-gray-500 mb-2">Comparação: Cardápio × Prescrito</p>
                  <div className="grid grid-cols-3 gap-3">
                    {[
                      {
                        label: "Proteínas", cor: "text-petroleo dark:text-turquesa",
                        atual: totalProteinas, prescrito: macrosPrescritas.proteinasG,
                        corAtual: "text-petroleo dark:text-turquesa",
                      },
                      {
                        label: "Lipídios", cor: "text-turquesa",
                        atual: totalLipidios, prescrito: macrosPrescritas.lipidiosG,
                        corAtual: "text-turquesa",
                      },
                      {
                        label: "Carboidratos", cor: "text-gray-900 dark:text-white",
                        atual: totalCarboidratos, prescrito: macrosPrescritas.carboidratosG,
                        corAtual: "text-gray-900 dark:text-white",
                      },
                    ].map(m => {
                      const diff = m.atual - m.prescrito
                      const pct = m.prescrito > 0 ? Math.round(diff / m.prescrito * 100) : 0
                      const ok = Math.abs(pct) <= 10
                      return (
                        <div key={m.label} className="text-center text-xs">
                          <p className="text-gray-500 mb-1">{m.label}</p>
                          <p className={`text-sm font-bold ${m.cor}`}>{m.atual.toFixed(1)}g</p>
                          <p className="text-gray-400">Prescrito: <span className="font-medium text-gray-600 dark:text-gray-300">{m.prescrito}g</span></p>
                          <p className={`mt-0.5 font-medium ${ok ? 'text-emerald-600' : 'text-amber-600'}`}>
                            {diff > 0 ? "+" : ""}{diff.toFixed(1)}g ({pct > 0 ? "+" : ""}{pct}%)
                          </p>
                        </div>
                      )
                    })}
                  </div>
                  <div className="mt-2 text-center text-xs text-gray-400">
                    Kcal no cardápio: <strong className="text-gray-700 dark:text-gray-200">{refeicoes.reduce((s, r) => s + r.totalKcal, 0)}</strong>
                    {" · "}Prescrito: <strong className="text-gray-700 dark:text-gray-200">{Math.round(macrosPrescritas.proteinasG * 4 + macrosPrescritas.lipidiosG * 9 + macrosPrescritas.carboidratosG * 4)} kcal</strong>
                  </div>
                </div>
              )}

              <div className="flex justify-between mt-4">
                <Button variant="outline" onClick={() => setStep("macros")}><ChevronLeft className="w-4 h-4" /> Voltar</Button>
                {refeicoes.some(r => r.alimentos.length > 0) && (
                  <Button variant="turquoise" onClick={handleGerarCardapio}>
                    Validar Cardápio <ClipboardCheck className="w-4 h-4" />
                  </Button>
                )}
              </div>
            </div>
          </div>
        )}

        {/* STEP 5 - VALIDAÇÃO */}
        {step === "validacao" && cardapio && macrosPrescritas && (
          <div className="space-y-6">
            <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-100 dark:border-gray-800 p-6 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-gray-900 dark:text-white flex items-center gap-2">
                  <ClipboardCheck className="w-5 h-5 text-turquesa" /> Validação: Prescrito vs Cardápio
                </h2>
                <div className="flex items-center gap-2">
                  <TabelaMicros refeicoes={refeicoes} />
                  <VisualizarDieta cardapio={cardapio} substitutosColecao={substitutosColecao} />
                </div>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-100 dark:border-gray-800">
                      <th className="text-left px-4 py-3 text-xs font-semibold text-gray-400 uppercase">Parâmetro</th>
                      <th className="text-left px-4 py-3 text-xs font-semibold text-gray-400 uppercase">Prescrito</th>
                      <th className="text-left px-4 py-3 text-xs font-semibold text-gray-400 uppercase">Cardápio</th>
                      <th className="text-left px-4 py-3 text-xs font-semibold text-gray-400 uppercase">Diferença</th>
                    </tr>
                  </thead>
                  <tbody>
                    {validacao.map((v, i) => (
                      <tr key={i} className="border-b border-gray-50 dark:border-gray-800/50">
                        <td className="px-4 py-3 text-sm font-medium text-gray-900 dark:text-white">{v.parametro}</td>
                        <td className="px-4 py-3 text-sm text-gray-600 dark:text-gray-400">{v.prescrito}</td>
                        <td className="px-4 py-3 text-sm text-gray-600 dark:text-gray-400">{v.cardapio}</td>
                        <td className="px-4 py-3">
                          <span className={`inline-flex items-center gap-1 text-sm font-medium ${v.alerta === "ok" ? 'text-emerald-600' : 'text-amber-600'}`}>
                            {v.alerta === "ok" ? <Check className="w-4 h-4" /> : <AlertTriangle className="w-4 h-4" />}
                            {v.diferenca}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {validacao.some(v => v.alerta === "atencao") && (
                <div className="mt-4 flex items-start gap-2 p-3 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg text-sm text-amber-800 dark:text-amber-300">
                  <AlertTriangle className="w-5 h-5 flex-shrink-0 mt-0.5" />
                  <div><strong>Atenção:</strong> Há diferenças relevantes entre o prescrito e o cardápio. Ajuste os alimentos ou quantidades nas refeições.</div>
                </div>
              )}
              {validacao.every(v => v.alerta === "ok") && (
                <div className="mt-4 flex items-start gap-2 p-3 bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-200 dark:border-emerald-800 rounded-lg text-sm text-emerald-800 dark:text-emerald-300">
                  <Check className="w-5 h-5 flex-shrink-0 mt-0.5" />
                  <div><strong>Validação OK!</strong> O cardápio está dentro dos parâmetros prescritos.</div>
                </div>
              )}
            </div>

            <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-100 dark:border-gray-800 p-6 shadow-sm">
              <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-4">Distribuição de Macronutrientes</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <GraficoMacros
                  proteinas={cardapio.totalProteinas}
                  lipidios={cardapio.totalLipidios}
                  carboidratos={cardapio.totalCarboidratos}
                  size={200}
                />
                <div className="grid grid-cols-2 gap-4 content-center">
                  <div className="text-center p-3 rounded-lg bg-petroleo/5 border border-petroleo/10 dark:border-petroleo/20">
                    <p className="text-xs text-gray-500">Proteínas</p>
                    <p className="text-lg font-bold text-petroleo dark:text-turquesa">{cardapio.totalProteinas}g</p>
                    <p className="text-xs text-gray-400">{Math.round(cardapio.totalProteinas * 4)} kcal</p>
                  </div>
                  <div className="text-center p-3 rounded-lg bg-turquesa/5 border border-turquesa/10 dark:border-turquesa/20">
                    <p className="text-xs text-gray-500">Lipídios</p>
                    <p className="text-lg font-bold text-turquesa">{cardapio.totalLipidios}g</p>
                    <p className="text-xs text-gray-400">{Math.round(cardapio.totalLipidios * 9)} kcal</p>
                  </div>
                  <div className="text-center p-3 rounded-lg bg-amber-50 dark:bg-amber-900/10 border border-amber-100 dark:border-amber-800">
                    <p className="text-xs text-gray-500">Carboidratos</p>
                    <p className="text-lg font-bold text-gray-900 dark:text-white">{cardapio.totalCarboidratos}g</p>
                    <p className="text-xs text-gray-400">{Math.round(cardapio.totalCarboidratos * 4)} kcal</p>
                  </div>
                  <div className="text-center p-3 rounded-lg bg-emerald-50 dark:bg-emerald-900/10 border border-emerald-100 dark:border-emerald-800">
                    <p className="text-xs text-gray-500">Fibras</p>
                    <p className="text-lg font-bold text-emerald-600">{cardapio.totalFibras}g</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex justify-between">
              <Button variant="outline" onClick={() => setStep("cardapio")}><ChevronLeft className="w-4 h-4" /> Ajustar Cardápio</Button>
              <Button variant="turquoise" onClick={handleSalvarPrescricao}>
                <Check className="w-4 h-4" /> {pacienteId ? (dietaEditandoId ? "Atualizar Dieta no Perfil" : "Salvar Dieta no Perfil") : "Salvar Prescrição"}
              </Button>
            </div>
          </div>
        )}

        <SubstitutoModal
          aberto={substitutoAberto}
          onClose={() => { setSubstitutoAberto(false); setSubstitutoInfo(null) }}
          onSelecionar={(alimento, qtd) => {
            if (!substitutoInfo) return
            const { refIdx, alimIdx } = substitutoInfo
            const key = `${refIdx}_${alimIdx}`
            setSubstitutosColecao(prev => ({
              ...prev, [key]: [...(prev[key] || []), { alimento, quantidade: qtd }]
            }))
            setSubstitutosExpandidos(prev => ({ ...prev, [key]: true }))
            addToast("success", `${alimento.nome} adicionado como substituto`)
            setSubstitutoAberto(false)
            setSubstitutoInfo(null)
          }}
        />
      </div>
      </ErrorBoundary>
    </AppLayout>
  )
}
