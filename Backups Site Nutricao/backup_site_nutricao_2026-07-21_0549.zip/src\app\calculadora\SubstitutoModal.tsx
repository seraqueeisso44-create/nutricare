"use client";
import { useState, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { buscarAlimentos, bancoAlimentos } from "@/lib/alimentos";
import type { AlimentoCompleto } from "@/lib/alimentos";
import { ArrowLeftRight, X, Search, Plus } from "lucide-react";

interface Props {
  aberto: boolean;
  onClose: () => void;
  onSelecionar: (alimento: AlimentoCompleto, qtd: number) => void;
}

export function SubstitutoModal({ aberto, onClose, onSelecionar }: Props) {
  const [busca, setBusca] = useState("");
  const [categoria, setCategoria] = useState("todas");
  const [qtd, setQtd] = useState(20);
  const [sel, setSel] = useState<AlimentoCompleto | null>(null);
  const [gramas, setGramas] = useState(100);

  const resultados = useMemo(() => {
    const base = busca.length >= 2 ? buscarAlimentos(busca) : bancoAlimentos;
    if (categoria === "todas") return base;
    return base.filter(a => a.nome.toLowerCase().includes(categoria.toLowerCase()));
  }, [busca, categoria]);

  if (!aberto) return null;

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40" onClick={onClose}>
        <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full mx-4 max-h-[85vh] flex flex-col" onClick={e => e.stopPropagation()}>
          <div className="flex items-center justify-between p-4 border-b border-gray-100 shrink-0">
            <h3 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
              <ArrowLeftRight className="w-5 h-5 text-turquesa" /> Adicionar Substituto
            </h3>
            <button onClick={onClose} className="p-1 rounded hover:bg-gray-100">
              <X className="w-5 h-5 text-gray-500" />
            </button>
          </div>

          <div className="p-4 border-b border-gray-100 shrink-0 space-y-2">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input type="text" placeholder="Buscar na TACO (597 alimentos)..." value={busca}
                onChange={e => { setBusca(e.target.value); setQtd(20); setSel(null) }}
                className="w-full pl-10 pr-4 h-10 rounded-lg border border-gray-200 text-sm focus:ring-2 focus:ring-turquesa" autoFocus />
            </div>
            <div className="flex gap-1.5 flex-wrap">
              {[
                { key: "todas", label: "Todas" },
                { key: "Arroz", label: "Cereais" },
                { key: "Feijão", label: "Leguminosas" },
                { key: "Frango", label: "Carnes" },
                { key: "Ovo", label: "Ovos/Laticínios" },
                { key: "Banana", label: "Frutas" },
                { key: "Batata", label: "Legumes" },
                { key: "Azeite", label: "Gorduras" },
                { key: "Castanha", label: "Oleaginosas" },
                { key: "Peixe", label: "Peixes" },
                { key: "Queijo", label: "Queijos" },
                { key: "Pão", label: "Panificados" },
                { key: "Leite", label: "Bebidas" },
              ].map(cat => (
                <button key={cat.key} onClick={() => setCategoria(cat.key)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-medium ${categoria === cat.key ? 'bg-petroleo text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}>
                  {cat.label}
                </button>
              ))}
            </div>
          </div>

          <div className="flex-1 overflow-y-auto p-3 space-y-1.5">
            {resultados.slice(0, qtd).map(alim => (
              <button key={alim.id} onClick={() => setSel(alim)}
                className={`w-full text-left px-3 py-2 rounded-lg text-sm border transition-all ${sel?.id === alim.id ? 'border-turquesa bg-turquesa/10 ring-1 ring-turquesa' : 'border-gray-100 hover:border-gray-200'}`}>
                <div className="flex items-center justify-between">
                  <span className="font-medium text-gray-900">{alim.nome}</span>
                  <span className="text-xs font-medium text-gray-500">{alim.kcal} kcal</span>
                </div>
                <p className="text-xs text-gray-400">P:{alim.proteinas}g L:{alim.lipidios}g C:{alim.carboidratos}g</p>
              </button>
            ))}
            {resultados.length > qtd && (
              <button onClick={() => setQtd(p => p + 20)} className="w-full text-center text-xs text-turquesa font-medium py-2">
                Ver +{Math.min(20, resultados.length - qtd)}
              </button>
            )}
            {resultados.length === 0 && <p className="text-center text-gray-400 py-6 text-sm">Nenhum resultado</p>}
          </div>

          <div className="p-4 border-t border-gray-100 shrink-0">
            <div className="flex items-end gap-3">
              <div className="w-28">
                <label className="text-xs text-gray-500 mb-1 block">Quantidade (g)</label>
                <input type="number" value={gramas} onChange={e => setGramas(Math.max(1, parseFloat(e.target.value) || 100))}
                  className="w-full h-9 px-3 rounded-lg border border-gray-200 text-sm" />
              </div>
              {sel && (
                <div className="flex-1 text-xs text-gray-500 pb-1">
                  <span className="font-medium text-gray-900">{sel.nome}</span>
                  <p>{Math.round(sel.kcal * gramas / sel.gramas)} kcal</p>
                </div>
              )}
              <Button size="sm" disabled={!sel} onClick={() => { if (sel) { onSelecionar(sel, gramas); onClose(); setSel(null); setGramas(100); setBusca(""); setQtd(20) } }}>
                <Plus className="w-3.5 h-3.5" /> Adicionar
              </Button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}