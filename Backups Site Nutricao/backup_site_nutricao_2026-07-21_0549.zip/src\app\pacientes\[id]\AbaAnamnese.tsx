"use client"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { anamneseVazia, calcularAguaIdeal, type Anamnese, type Paciente } from "@/lib/pacientes"
import { CampoTexto, CampoArea, SecaoTitulo } from "../[id]/campos"
import { Droplet, Save } from "lucide-react"

export function AbaAnamnese({
  paciente, onSalvar,
}: { paciente: Paciente; onSalvar: (a: Anamnese) => void }) {
  const [form, setForm] = useState<Anamnese>({ ...anamneseVazia(), ...(paciente.anamnese || {}) })
  const set = (k: keyof Anamnese, v: string) => setForm(p => ({ ...p, [k]: v }))

  const aguaIdealMl = calcularAguaIdeal(paciente.peso)
  const aguaIdealL = (aguaIdealMl / 1000).toFixed(1)

  return (
    <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-100 dark:border-gray-800 p-6 shadow-sm space-y-5">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Anamnese</h2>
        <Button size="sm" onClick={() => onSalvar(form)}><Save className="w-4 h-4" /> Salvar Anamnese</Button>
      </div>

      <SecaoTitulo>Histórico Clínico</SecaoTitulo>
      <CampoArea label="Queixa Principal" valor={form.queixaPrincipal} onChange={v => set("queixaPrincipal", v)} placeholder="Qual o motivo principal da consulta?" />
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <CampoArea label="Doenças Atuais" valor={form.doencasAtuais} onChange={v => set("doencasAtuais", v)} placeholder="Diabetes, hipertensão, etc." />
        <CampoArea label="Doenças Anteriores" valor={form.doencasAnteriores} onChange={v => set("doencasAnteriores", v)} placeholder="Histórico de doenças" />
        <CampoArea label="Cirurgias" valor={form.cirurgias} onChange={v => set("cirurgias", v)} placeholder="Cirurgias realizadas" />
        <CampoArea label="Histórico Familiar" valor={form.historicoFamiliar} onChange={v => set("historicoFamiliar", v)} placeholder="Doenças na família" />
        <CampoArea label="Medicamentos em Uso" valor={form.medicamentos} onChange={v => set("medicamentos", v)} placeholder="Lista de medicamentos" />
        <CampoArea label="Suplementos" valor={form.suplementos} onChange={v => set("suplementos", v)} placeholder="Vitaminas, proteínas, etc." />
        <CampoArea label="Alergias" valor={form.alergias} onChange={v => set("alergias", v)} placeholder="Alergias alimentares ou outras" />
        <CampoArea label="Intolerâncias Alimentares" valor={form.intolerancias} onChange={v => set("intolerancias", v)} placeholder="Lactose, glúten, etc." />
      </div>
      <CampoArea label="Hábitos Intestinais" valor={form.habitosIntestinais} onChange={v => set("habitosIntestinais", v)} />

      <SecaoTitulo>Estilo de Vida</SecaoTitulo>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <CampoTexto label="Atividade Física" valor={form.atividadeFisica} onChange={v => set("atividadeFisica", v)} placeholder="Tipo de exercício" />
        <CampoTexto label="Frequência" valor={form.frequenciaAtividade} onChange={v => set("frequenciaAtividade", v)} placeholder="Ex: 3x por semana" />
        <CampoTexto label="Horas de Sono" valor={form.horasSono} onChange={v => set("horasSono", v)} placeholder="Ex: 7-8 horas" />
        <CampoTexto label="Qualidade do Sono" valor={form.qualidadeSono} onChange={v => set("qualidadeSono", v)} placeholder="Bom, regular, ruim" />
        <CampoTexto label="Nível de Estresse" valor={form.nivelEstresse} onChange={v => set("nivelEstresse", v)} placeholder="Baixo, moderado, alto" />
        <CampoTexto label="Tabagismo" valor={form.tabagismo} onChange={v => set("tabagismo", v)} />
        <CampoTexto label="Consumo de Álcool" valor={form.consumoAlcool} onChange={v => set("consumoAlcool", v)} />
        <div>
          <label className="text-xs font-medium text-gray-500 mb-1 block">Consumo de Água</label>
          <input type="text" value={form.consumoAgua} onChange={e => set("consumoAgua", e.target.value)} placeholder="Ex: 2 litros por dia"
            className="w-full h-10 px-3 rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm focus:ring-2 focus:ring-turquesa dark:text-white" />
          {aguaIdealMl > 0 && (
            <p className="mt-1 flex items-center gap-1 text-xs text-turquesa">
              <Droplet className="w-3 h-3" /> Ingestão ideal estimada: <strong>{aguaIdealL} L/dia</strong> ({aguaIdealMl} ml · peso × 35 ml)
            </p>
          )}
        </div>
      </div>

      <SecaoTitulo>Hábitos Alimentares</SecaoTitulo>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <CampoTexto label="Refeições por Dia" valor={form.refeicoesPorDia} onChange={v => set("refeicoesPorDia", v)} placeholder="Número de refeições" />
        <CampoTexto label="Horários das Refeições" valor={form.horariosRefeicoes} onChange={v => set("horariosRefeicoes", v)} placeholder="Ex: 7h, 12h, 15h, 19h" />
        <CampoArea label="Preferências Alimentares" valor={form.preferencias} onChange={v => set("preferencias", v)} placeholder="Alimentos que gosta" />
        <CampoArea label="Aversões Alimentares" valor={form.aversoes} onChange={v => set("aversoes", v)} placeholder="Alimentos que não gosta" />
        <CampoTexto label="Frequência de Refeições Fora" valor={form.frequenciaRefeicoesFora} onChange={v => set("frequenciaRefeicoesFora", v)} placeholder="Ex: 2x por semana" />
        <CampoTexto label="Quem Prepara as Refeições" valor={form.quemPreparaRefeicoes} onChange={v => set("quemPreparaRefeicoes", v)} placeholder="Próprio paciente, familiar, etc." />
      </div>
      <CampoArea label="Restrições Alimentares" valor={form.restricoes} onChange={v => set("restricoes", v)} placeholder="Vegetariano, vegano, sem glúten, etc." />

      <SecaoTitulo>Objetivos e Expectativas</SecaoTitulo>
      <CampoArea label="Objetivos" valor={form.objetivos} onChange={v => set("objetivos", v)} placeholder="Quais são os objetivos do paciente?" />
      <CampoArea label="Expectativas" valor={form.expectativas} onChange={v => set("expectativas", v)} placeholder="O que o paciente espera do acompanhamento?" />
      <CampoArea label="Observações Adicionais" valor={form.observacoesAdicionais} onChange={v => set("observacoesAdicionais", v)} placeholder="Outras informações relevantes" />

      <div className="flex justify-end pt-2">
        <Button onClick={() => onSalvar(form)}><Save className="w-4 h-4" /> Salvar Anamnese</Button>
      </div>
    </div>
  )
}
