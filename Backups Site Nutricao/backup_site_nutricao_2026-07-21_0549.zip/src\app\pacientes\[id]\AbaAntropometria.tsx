"use client"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { useToast } from "@/components/ui/toast"
import {
  calcularIMC, classificarIMC, calcularIdade, estimarAlturaJoelho,
  type Paciente, type RegistroAntropometria, type DobrasCutaneas, type Circunferencias,
} from "@/lib/pacientes"
import { CampoNumero, CampoArea, SecaoTitulo, inputCls, labelCls } from "../[id]/campos"
import { Plus, Trash2, Ruler } from "lucide-react"

const DOBRAS: { key: keyof DobrasCutaneas; label: string }[] = [
  { key: "triceps", label: "Tríceps" }, { key: "biceps", label: "Bíceps" },
  { key: "subescapular", label: "Subescapular" }, { key: "suprailiaca", label: "Suprailíaca" },
  { key: "abdominal", label: "Abdominal" }, { key: "toracica", label: "Torácica" },
  { key: "axilarMedia", label: "Axilar Média" }, { key: "coxa", label: "Coxa" },
  { key: "panturrilha", label: "Panturrilha" }, { key: "supraespinhal", label: "Supraespinhal" },
]

const CIRC: { key: keyof Circunferencias; label: string }[] = [
  { key: "pescoco", label: "Pescoço" }, { key: "ombro", label: "Ombro" },
  { key: "torax", label: "Tórax" }, { key: "bracoRelaxado", label: "Braço Relaxado" },
  { key: "bracoContraido", label: "Braço Contraído" }, { key: "antebraco", label: "Antebraço" },
  { key: "cintura", label: "Cintura" }, { key: "abdomen", label: "Abdômen" },
  { key: "quadril", label: "Quadril" }, { key: "coxa", label: "Coxa" },
  { key: "panturrilha", label: "Panturrilha" },
]

const hoje = () => new Date().toISOString().slice(0, 10)

function novoRegistro(peso: number, altura: number): RegistroAntropometria {
  return {
    id: `an_${Date.now()}`, data: hoje(), incluirGrafico: true,
    peso: peso || 0, altura: altura || 0, formulaGordura: "nenhuma",
    dobras: {}, circunferencias: {}, observacoes: "",
  }
}

export function AbaAntropometria({
  paciente, onSalvar,
}: { paciente: Paciente; onSalvar: (registros: RegistroAntropometria[]) => void }) {
  const { addToast } = useToast()
  const registros = paciente.antropometria || []
  const idade = calcularIdade(paciente.dataNascimento)
  const [form, setForm] = useState<RegistroAntropometria>(novoRegistro(paciente.peso, paciente.altura))

  const setF = (k: keyof RegistroAntropometria, v: any) => setForm(p => ({ ...p, [k]: v }))
  const setDobra = (k: keyof DobrasCutaneas, v: number) => setForm(p => ({ ...p, dobras: { ...p.dobras, [k]: v } }))
  const setCirc = (k: keyof Circunferencias, v: number) => setForm(p => ({ ...p, circunferencias: { ...p.circunferencias, [k]: v } }))

  const alturaEstimada = form.alturaJoelho ? estimarAlturaJoelho(form.alturaJoelho, idade, paciente.sexo) : 0
  const imc = calcularIMC(form.peso, form.altura || alturaEstimada)
  const classe = classificarIMC(imc)

  const salvar = () => {
    if (!form.peso) { addToast("error", "Informe ao menos o peso"); return }
    const reg = { ...form, altura: form.altura || alturaEstimada }
    onSalvar([reg, ...registros])
    setForm(novoRegistro(paciente.peso, paciente.altura))
    addToast("success", "Medição registrada")
  }

  const remover = (id: string) => onSalvar(registros.filter(r => r.id !== id))

  return (
    <div className="space-y-4">
      <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-100 dark:border-gray-800 p-6 shadow-sm space-y-5">
        <div className="flex items-center gap-2">
          <Ruler className="w-5 h-5 text-turquesa" />
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Nova Medição</h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label className={labelCls}>Data da Medição</label>
            <input type="date" value={form.data} onChange={e => setF("data", e.target.value)} className={inputCls} />
          </div>
          <label className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-300 sm:col-span-2 sm:mt-6">
            <input type="checkbox" checked={form.incluirGrafico} onChange={e => setF("incluirGrafico", e.target.checked)}
              className="w-4 h-4 rounded accent-turquesa" />
            Incluir no gráfico (para futuros comparativos)
          </label>
        </div>

        <SecaoTitulo>Dados Básicos</SecaoTitulo>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <CampoNumero label="Peso (kg)" valor={form.peso} onChange={v => setF("peso", v)} step={0.1} />
          <CampoNumero label="Altura (cm)" valor={form.altura} onChange={v => setF("altura", v)} step={0.1} />
          <CampoNumero label="Altura do joelho (cm)" valor={form.alturaJoelho} onChange={v => setF("alturaJoelho", v)} step={0.1} placeholder="opcional" />
        </div>
        {alturaEstimada > 0 && (
          <p className="text-xs text-gray-500">
            Altura estimada (Chumlea et al., 1985): <strong className="text-turquesa">{alturaEstimada} cm</strong> — para pacientes acamados, cadeirantes ou idosos com cifose.
          </p>
        )}
        {imc > 0 && (
          <div className="inline-flex items-center gap-3 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
            <div className="text-center"><p className="text-xs text-gray-500">IMC</p><p className="text-xl font-bold text-petroleo dark:text-turquesa">{imc}</p></div>
            <p className={`text-sm font-semibold ${classe.cor}`}>{classe.rotulo}</p>
          </div>
        )}

        <SecaoTitulo>Dobras Cutâneas (mm)</SecaoTitulo>
        <div>
          <label className={labelCls}>Fórmula de cálculo</label>
          <select value={form.formulaGordura} onChange={e => setF("formulaGordura", e.target.value)} className={inputCls}>
            <option value="nenhuma">Nenhuma (apenas registrar dobras)</option>
          </select>
          <p className="text-xs text-gray-400 mt-1">Nenhuma fórmula selecionada — registre as dobras desejadas; o % de gordura não será calculado automaticamente.</p>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
          {DOBRAS.map(d => (
            <CampoNumero key={d.key} label={d.label} valor={form.dobras[d.key]} onChange={v => setDobra(d.key, v)} step={0.1} placeholder="mm" />
          ))}
        </div>

        <SecaoTitulo>Circunferências (cm)</SecaoTitulo>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
          {CIRC.map(c => (
            <CampoNumero key={c.key} label={c.label} valor={form.circunferencias[c.key]} onChange={v => setCirc(c.key, v)} step={0.1} placeholder="cm" />
          ))}
        </div>

        <CampoArea label="Observações" valor={form.observacoes} onChange={v => setF("observacoes", v)} placeholder="Observações sobre a medição..." />

        <div className="flex justify-end">
          <Button onClick={salvar}><Plus className="w-4 h-4" /> Registrar Medição</Button>
        </div>
      </div>

      <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-100 dark:border-gray-800 p-6 shadow-sm">
        <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Histórico de Medições ({registros.length})</h2>
        {registros.length === 0 ? (
          <p className="text-center text-sm text-gray-400 py-4">Nenhuma medição registrada.</p>
        ) : (
          <div className="space-y-2">
            {registros.map(r => {
              const rimc = calcularIMC(r.peso, r.altura)
              return (
                <div key={r.id} className="flex items-center justify-between p-3 rounded-lg border border-gray-100 dark:border-gray-800">
                  <div className="flex items-center gap-4 text-sm">
                    <span className="font-medium text-gray-900 dark:text-white">{new Date(r.data + "T00:00:00").toLocaleDateString("pt-BR")}</span>
                    <span className="text-gray-500">Peso: <strong>{r.peso}kg</strong></span>
                    {r.altura > 0 && <span className="text-gray-500">Alt: {r.altura}cm</span>}
                    {rimc > 0 && <span className="text-gray-500">IMC: {rimc}</span>}
                    {r.incluirGrafico && <span className="text-[10px] px-2 py-0.5 rounded-full bg-turquesa/10 text-turquesa">no gráfico</span>}
                  </div>
                  <button onClick={() => remover(r.id)} className="p-1.5 rounded-lg hover:bg-red-50 dark:hover:bg-red-900/20 text-gray-400 hover:text-red-500">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}
