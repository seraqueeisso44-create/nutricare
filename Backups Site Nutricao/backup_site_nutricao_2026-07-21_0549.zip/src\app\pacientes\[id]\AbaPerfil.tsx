"use client"
import { Button } from "@/components/ui/button"
import { calcularIdade, type Paciente } from "@/lib/pacientes"
import { Pencil } from "lucide-react"

export function AbaPerfil({ paciente, onEditar }: { paciente: Paciente; onEditar: () => void }) {
  const idade = calcularIdade(paciente.dataNascimento)
  const dataFmt = paciente.dataNascimento
    ? new Date(paciente.dataNascimento + "T00:00:00").toLocaleDateString("pt-BR")
    : "—"

  const itens = [
    { label: "Nome Completo", valor: paciente.nome },
    { label: "CPF", valor: paciente.cpf || "—" },
    { label: "Data de Nascimento", valor: `${dataFmt}${idade ? ` (${idade} anos)` : ""}` },
    { label: "Sexo", valor: paciente.sexo === "masculino" ? "Masculino" : "Feminino" },
    { label: "Profissão", valor: paciente.profissao || "—" },
    { label: "E-mail", valor: paciente.email || "—" },
    { label: "Telefone", valor: paciente.telefone || "—" },
    { label: "Objetivo", valor: paciente.objetivo || "—" },
  ]

  return (
    <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-100 dark:border-gray-800 p-6 shadow-sm">
      <div className="flex items-center justify-between mb-5">
        <div>
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Dados Pessoais</h2>
          <p className="text-xs text-gray-500">Informações de cadastro do paciente</p>
        </div>
        <Button variant="outline" size="sm" onClick={onEditar}><Pencil className="w-4 h-4" /> Editar</Button>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-4">
        {itens.map(i => (
          <div key={i.label} className="border-b border-gray-50 dark:border-gray-800 pb-2">
            <p className="text-xs text-gray-400">{i.label}</p>
            <p className="text-sm font-medium text-gray-900 dark:text-white">{i.valor}</p>
          </div>
        ))}
      </div>
      {paciente.observacoes && (
        <div className="mt-4">
          <p className="text-xs text-gray-400">Observações</p>
          <p className="text-sm text-gray-700 dark:text-gray-300 whitespace-pre-wrap">{paciente.observacoes}</p>
        </div>
      )}
    </div>
  )
}
