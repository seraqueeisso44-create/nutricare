"use client"
import { useState, useEffect, use } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { TopNav } from "@/components/layout/TopNav"
import { Button } from "@/components/ui/button"
import {
  obterPaciente, atualizarPaciente, calcularIdade, calcularIMC, classificarIMC,
  type Paciente, type Anamnese, type Anexo, type RegistroAntropometria, type RegistroCalculo,
} from "@/lib/pacientes"
import { AbaPerfil } from "./AbaPerfil"
import { AbaAnamnese } from "./AbaAnamnese"
import { AbaAnexos } from "./AbaAnexos"
import { AbaAntropometria } from "./AbaAntropometria"
import { AbaCalculo } from "./AbaCalculo"
import { AbaGraficos } from "./AbaGraficos"
import { AbaDieta } from "./AbaDieta"
import { AbaOrientacoes } from "./AbaOrientacoes"
import {
  ArrowLeft, User, ClipboardList, FlaskConical, Image as ImageIcon,
  Ruler, Calculator, TrendingUp, FileText, Calendar, UtensilsCrossed,
} from "lucide-react"

const ABAS = [
  { id: "perfil", label: "Perfil", icon: User },
  { id: "anamnese", label: "Anamnese", icon: ClipboardList },
  { id: "exames", label: "Exames", icon: FlaskConical },
  { id: "fotos", label: "Fotos", icon: ImageIcon },
  { id: "antropometria", label: "Antropometria", icon: Ruler },
  { id: "calculo", label: "Cálculo Energético", icon: Calculator },
  { id: "dieta", label: "Dieta", icon: UtensilsCrossed },
  { id: "graficos", label: "Gráficos", icon: TrendingUp },
  { id: "orientacoes", label: "Orientações", icon: FileText },
] as const

type AbaId = (typeof ABAS)[number]["id"]

export default function PacienteDetalhePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params)
  const router = useRouter()
  const [paciente, setPaciente] = useState<Paciente | null>(null)
  const [carregado, setCarregado] = useState(false)
  const [aba, setAba] = useState<AbaId>("perfil")

  useEffect(() => {
    const p = obterPaciente(id)
    setPaciente(p || null)
    setCarregado(true)
  }, [id])

  const salvar = (dados: Partial<Paciente>) => {
    const atualizado = atualizarPaciente(id, dados)
    if (atualizado) setPaciente(atualizado)
  }

  if (!carregado) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-950">
        <TopNav />
        <main className="max-w-5xl mx-auto p-6"><p className="text-sm text-gray-400">Carregando...</p></main>
      </div>
    )
  }

  if (!paciente) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-950">
        <TopNav />
        <main className="max-w-5xl mx-auto p-6 text-center py-20">
          <p className="text-sm text-gray-500 mb-4">Paciente não encontrado.</p>
          <Link href="/pacientes"><Button variant="outline"><ArrowLeft className="w-4 h-4" /> Voltar para lista</Button></Link>
        </main>
      </div>
    )
  }

  const idade = calcularIdade(paciente.dataNascimento)
  const imc = calcularIMC(paciente.peso, paciente.altura)
  const classe = classificarIMC(imc)

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950">
      <TopNav />
      <main className="max-w-5xl mx-auto p-6 space-y-5">
        <button onClick={() => router.push("/pacientes")}
          className="flex items-center gap-1.5 text-sm text-gray-500 hover:text-turquesa transition-colors">
          <ArrowLeft className="w-4 h-4" /> Voltar
        </button>

        <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-100 dark:border-gray-800 p-6 shadow-sm">
          <div className="flex flex-col sm:flex-row sm:items-center gap-4">
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-petroleo to-turquesa flex items-center justify-center text-white text-2xl font-bold shrink-0">
              {paciente.nome.charAt(0).toUpperCase()}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className="text-xl font-bold text-gray-900 dark:text-white">{paciente.nome}</h1>
                <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${paciente.status === "ativo" ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400" : "bg-gray-100 text-gray-500 dark:bg-gray-800"}`}>
                  {paciente.status === "ativo" ? "Ativo" : "Inativo"}
                </span>
              </div>
              <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-gray-400 mt-1">
                {idade > 0 && <span className="flex items-center gap-1"><Calendar className="w-3 h-3" /> {idade} anos</span>}
                {paciente.email && <span>{paciente.email}</span>}
                {paciente.telefone && <span>{paciente.telefone}</span>}
              </div>
            </div>
            <div className="flex items-center gap-4">
              {paciente.peso > 0 && <div className="text-center"><p className="text-lg font-bold text-gray-800 dark:text-gray-200">{paciente.peso}kg</p><p className="text-xs text-gray-400">peso</p></div>}
              {imc > 0 && <div className="text-center"><p className="text-lg font-bold text-petroleo dark:text-turquesa">{imc}</p><p className={`text-xs ${classe.cor}`}>{classe.rotulo}</p></div>}
              <Link href={`/calculadora?paciente=${paciente.id}`}>
                <Button size="sm"><Calculator className="w-4 h-4" /> Calcular dieta</Button>
              </Link>
            </div>
          </div>
        </div>

        <div className="flex gap-1 overflow-x-auto pb-1 border-b border-gray-200 dark:border-gray-800">
          {ABAS.map(a => {
            const Icon = a.icon
            const ativo = aba === a.id
            return (
              <button key={a.id} onClick={() => setAba(a.id)}
                className={`flex items-center gap-1.5 px-3.5 py-2.5 text-sm font-medium whitespace-nowrap border-b-2 -mb-px transition-colors ${ativo ? "border-turquesa text-turquesa" : "border-transparent text-gray-500 hover:text-gray-800 dark:hover:text-gray-200"}`}>
                <Icon className="w-4 h-4" /> {a.label}
              </button>
            )
          })}
        </div>

        <div>
          {aba === "perfil" && (
            <AbaPerfil paciente={paciente} onEditar={() => router.push("/pacientes")} />
          )}
          {aba === "anamnese" && (
            <AbaAnamnese paciente={paciente} onSalvar={(a: Anamnese) => salvar({ anamnese: a })} />
          )}
          {aba === "exames" && (
            <AbaAnexos titulo="Exames Laboratoriais"
              descricao="Anexe resultados de exames (PDF, imagens, documentos)."
              anexos={paciente.exames || []}
              onChange={(anexos: Anexo[]) => salvar({ exames: anexos })} />
          )}
          {aba === "fotos" && (
            <AbaAnexos titulo="Fotos de Evolução"
              descricao="Registre fotos da evolução física do paciente."
              anexos={paciente.fotos || []} somenteImagens
              onChange={(anexos: Anexo[]) => salvar({ fotos: anexos })} />
          )}
          {aba === "antropometria" && (
            <AbaAntropometria paciente={paciente}
              onSalvar={(registros: RegistroAntropometria[]) => salvar({ antropometria: registros })} />
          )}
          {aba === "calculo" && (
            <AbaCalculo paciente={paciente}
              onSalvar={(registros: RegistroCalculo[]) => salvar({ calculos: registros })} />
          )}
          {aba === "dieta" && (
            <AbaDieta paciente={paciente}
              onRemover={(dietaId: string) => salvar({ dietas: (paciente.dietas || []).filter(d => d.id !== dietaId) })} />
          )}
          {aba === "graficos" && <AbaGraficos paciente={paciente} />}
          {aba === "orientacoes" && (
            <AbaOrientacoes paciente={paciente} onSalvar={(o: string) => salvar({ orientacoes: o })} />
          )}
        </div>
      </main>
    </div>
  )
}
