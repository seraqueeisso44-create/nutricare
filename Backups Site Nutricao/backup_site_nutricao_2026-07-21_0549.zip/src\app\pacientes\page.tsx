"use client"
import { useState, useEffect, useMemo } from "react"
import Link from "next/link"
import { TopNav } from "@/components/layout/TopNav"
import { Button } from "@/components/ui/button"
import { useToast } from "@/components/ui/toast"
import { PacienteModal } from "./PacienteModal"
import {
  carregarPacientes, criarPaciente, atualizarPaciente, removerPaciente,
  calcularIdade, calcularIMC, type Paciente,
} from "@/lib/pacientes"
import {
  Plus, Search, Users, UserCheck, UserX, Pencil, Trash2,
  Calculator, Mail, Phone, Target,
} from "lucide-react"

export default function PacientesPage() {
  const { addToast } = useToast()
  const [pacientes, setPacientes] = useState<Paciente[]>([])
  const [busca, setBusca] = useState("")
  const [filtro, setFiltro] = useState<"todos" | "ativo" | "inativo">("todos")
  const [modalAberto, setModalAberto] = useState(false)
  const [editando, setEditando] = useState<Paciente | null>(null)
  const [confirmarRemocao, setConfirmarRemocao] = useState<Paciente | null>(null)

  useEffect(() => { setPacientes(carregarPacientes()) }, [])

  const recarregar = () => setPacientes(carregarPacientes())

  const filtrados = useMemo(() => {
    const q = busca.toLowerCase().trim()
    return pacientes.filter(p => {
      const matchBusca = !q || p.nome.toLowerCase().includes(q) || p.email.toLowerCase().includes(q) || p.telefone.includes(q)
      const matchFiltro = filtro === "todos" || p.status === filtro
      return matchBusca && matchFiltro
    })
  }, [pacientes, busca, filtro])

  const stats = useMemo(() => ({
    total: pacientes.length,
    ativos: pacientes.filter(p => p.status === "ativo").length,
    inativos: pacientes.filter(p => p.status === "inativo").length,
  }), [pacientes])

  const abrirNovo = () => { setEditando(null); setModalAberto(true) }
  const abrirEdicao = (p: Paciente) => { setEditando(p); setModalAberto(true) }

  const handleSalvar = (dados: Omit<Paciente, "id" | "criadoEm" | "atualizadoEm">) => {
    if (editando) {
      atualizarPaciente(editando.id, dados)
      addToast("success", "Paciente atualizado")
    } else {
      criarPaciente(dados)
      addToast("success", "Paciente cadastrado")
    }
    setModalAberto(false)
    setEditando(null)
    recarregar()
  }

  const handleRemover = () => {
    if (!confirmarRemocao) return
    removerPaciente(confirmarRemocao.id)
    addToast("success", "Paciente removido")
    setConfirmarRemocao(null)
    recarregar()
  }

  const cards = [
    { label: "Total de pacientes", valor: stats.total, icon: Users, cor: "text-petroleo dark:text-turquesa", bg: "bg-petroleo/5 dark:bg-turquesa/10" },
    { label: "Ativos", valor: stats.ativos, icon: UserCheck, cor: "text-emerald-600", bg: "bg-emerald-50 dark:bg-emerald-900/10" },
    { label: "Inativos", valor: stats.inativos, icon: UserX, cor: "text-gray-500", bg: "bg-gray-100 dark:bg-gray-800" },
  ]

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950">
      <TopNav />
      <main className="max-w-6xl mx-auto p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Pacientes</h1>
            <p className="text-sm text-gray-500">Cadastre e gerencie seus pacientes</p>
          </div>
          <Button onClick={abrirNovo}><Plus className="w-4 h-4" /> Novo Paciente</Button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {cards.map(c => {
            const Icon = c.icon
            return (
              <div key={c.label} className="bg-white dark:bg-gray-900 rounded-xl border border-gray-100 dark:border-gray-800 p-5 shadow-sm flex items-center gap-4">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${c.bg}`}>
                  <Icon className={`w-6 h-6 ${c.cor}`} />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">{c.valor}</p>
                  <p className="text-xs text-gray-500">{c.label}</p>
                </div>
              </div>
            )
          })}
        </div>

        <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-100 dark:border-gray-800 shadow-sm">
          <div className="p-4 border-b border-gray-100 dark:border-gray-800 flex flex-col sm:flex-row gap-3 sm:items-center justify-between">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input type="text" placeholder="Buscar por nome, e-mail ou telefone..." value={busca}
                onChange={e => setBusca(e.target.value)}
                className="w-full pl-10 pr-4 h-10 rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm focus:ring-2 focus:ring-turquesa dark:text-white" />
            </div>
            <div className="flex gap-1.5">
              {([["todos", "Todos"], ["ativo", "Ativos"], ["inativo", "Inativos"]] as const).map(([k, label]) => (
                <button key={k} onClick={() => setFiltro(k)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium ${filtro === k ? "bg-petroleo text-white" : "bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300 hover:bg-gray-200"}`}>
                  {label}
                </button>
              ))}
            </div>
          </div>

          {filtrados.length === 0 ? (
            <div className="p-12 text-center">
              <Users className="w-10 h-10 text-gray-300 mx-auto mb-3" />
              <p className="text-sm text-gray-500">
                {pacientes.length === 0 ? "Nenhum paciente cadastrado ainda." : "Nenhum paciente encontrado."}
              </p>
              {pacientes.length === 0 && (
                <Button className="mt-4" size="sm" onClick={abrirNovo}><Plus className="w-4 h-4" /> Cadastrar primeiro paciente</Button>
              )}
            </div>
          ) : (
            <div className="divide-y divide-gray-50 dark:divide-gray-800">
              {filtrados.map(p => {
                const idade = calcularIdade(p.dataNascimento)
                const imc = calcularIMC(p.peso, p.altura)
                return (
                  <div key={p.id} className="p-4 flex flex-col md:flex-row md:items-center gap-3 hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors">
                    <Link href={`/pacientes/${p.id}`} className="flex items-center gap-3 flex-1 min-w-0 group">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-petroleo to-turquesa flex items-center justify-center text-white font-semibold shrink-0">
                        {p.nome.charAt(0).toUpperCase()}
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-gray-900 dark:text-white truncate group-hover:text-turquesa transition-colors">{p.nome}</span>
                          <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${p.status === "ativo" ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400" : "bg-gray-100 text-gray-500 dark:bg-gray-800"}`}>
                            {p.status === "ativo" ? "Ativo" : "Inativo"}
                          </span>
                        </div>
                        <div className="flex flex-wrap items-center gap-x-3 gap-y-0.5 text-xs text-gray-400 mt-0.5">
                          {p.email && <span className="flex items-center gap-1 truncate"><Mail className="w-3 h-3" /> {p.email}</span>}
                          {p.telefone && <span className="flex items-center gap-1"><Phone className="w-3 h-3" /> {p.telefone}</span>}
                          {p.objetivo && <span className="flex items-center gap-1"><Target className="w-3 h-3" /> {p.objetivo}</span>}
                        </div>
                      </div>
                    </Link>

                    <div className="flex items-center gap-4 text-xs text-gray-500 md:mr-2">
                      {idade > 0 && <div className="text-center"><p className="font-semibold text-gray-700 dark:text-gray-300">{idade}</p><p>anos</p></div>}
                      {p.peso > 0 && <div className="text-center"><p className="font-semibold text-gray-700 dark:text-gray-300">{p.peso}kg</p><p>peso</p></div>}
                      {imc > 0 && <div className="text-center"><p className="font-semibold text-gray-700 dark:text-gray-300">{imc}</p><p>IMC</p></div>}
                    </div>

                    <div className="flex items-center gap-1 shrink-0">
                      <Link href={`/calculadora?paciente=${p.id}`}
                        className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium text-turquesa hover:bg-turquesa/10 transition-colors" title="Calcular dieta">
                        <Calculator className="w-4 h-4" /> Calcular
                      </Link>
                      <button onClick={() => abrirEdicao(p)}
                        className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-400 hover:text-amber-500 transition-colors" title="Editar">
                        <Pencil className="w-4 h-4" />
                      </button>
                      <button onClick={() => setConfirmarRemocao(p)}
                        className="p-2 rounded-lg hover:bg-red-50 dark:hover:bg-red-900/20 text-gray-400 hover:text-red-500 transition-colors" title="Remover">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </div>
      </main>

      <PacienteModal
        aberto={modalAberto}
        paciente={editando}
        onClose={() => { setModalAberto(false); setEditando(null) }}
        onSalvar={handleSalvar}
      />

      {confirmarRemocao && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" onClick={() => setConfirmarRemocao(null)}>
          <div className="bg-white dark:bg-gray-900 rounded-xl shadow-2xl max-w-sm w-full p-6" onClick={e => e.stopPropagation()}>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-1">Remover paciente</h3>
            <p className="text-sm text-gray-500 mb-4">Tem certeza que deseja remover <strong>{confirmarRemocao.nome}</strong>? Esta ação não pode ser desfeita.</p>
            <div className="flex gap-2">
              <Button variant="outline" className="flex-1" onClick={() => setConfirmarRemocao(null)}>Cancelar</Button>
              <Button variant="danger" className="flex-1" onClick={handleRemover}>Remover</Button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
