"use client"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { LayoutDashboard, Calculator, Apple } from "lucide-react"

export function TopNav() {
  const pathname = usePathname()
  const links = [
    { href: "/pacientes", label: "Pacientes", icon: LayoutDashboard },
    { href: "/calculadora", label: "Calculadora", icon: Calculator },
  ]
  return (
    <header className="sticky top-0 z-40 bg-white/90 dark:bg-gray-900/90 backdrop-blur border-b border-gray-100 dark:border-gray-800">
      <div className="max-w-6xl mx-auto px-6 h-14 flex items-center justify-between">
        <Link href="/pacientes" className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-petroleo to-turquesa flex items-center justify-center">
            <Apple className="w-4 h-4 text-white" />
          </div>
          <span className="font-bold text-gray-900 dark:text-white">NutriCare</span>
        </Link>
        <nav className="flex items-center gap-1">
          {links.map(l => {
            const Icon = l.icon
            const active = pathname === l.href || pathname.startsWith(l.href + "/")
            return (
              <Link key={l.href} href={l.href}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${active ? "bg-petroleo text-white" : "text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800"}`}>
                <Icon className="w-4 h-4" />
                <span className="hidden sm:inline">{l.label}</span>
              </Link>
            )
          })}
        </nav>
      </div>
    </header>
  )
}
